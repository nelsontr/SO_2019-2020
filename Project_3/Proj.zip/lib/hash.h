#ifndef HASH_H
#define HASH_H

int hash(char* name, int n);

#endif

